export default function push(remote?: string): string;
