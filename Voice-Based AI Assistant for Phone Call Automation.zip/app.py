import os
from flask import Flask, request
from twilio.twiml.voice_response import VoiceResponse, Gather
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Store conversation state
conversation_data = {}

@app.route("/answer", methods=['POST'])
def answer_call():
    """Handle incoming calls from Twilio"""
    # Get the caller's phone number
    caller_number = request.values.get('From', '')
    call_sid = request.values.get('CallSid', '')
    
    # Initialize conversation state for this call
    conversation_data[call_sid] = {
        'name': None,
        'phone_number': caller_number,
        'business_name': None,
        'service_requested': None,
        'vehicle_info': None,
        'service_location': None,
        'current_step': 'greeting'
    }
    
    # Create TwiML response
    response = VoiceResponse()
    
    # Add initial greeting and ask for name
    gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=3)
    gather.say("Thanks for calling the Locksmith, this is Angi, may I know your name?")
    response.append(gather)
    
    # If no input is received, retry
    response.redirect('/answer')
    
    return str(response)

@app.route("/handle-response", methods=['POST'])
def handle_response():
    """Process user's speech response"""
    # Get call SID and speech result
    call_sid = request.values.get('CallSid', '')
    speech_result = request.values.get('SpeechResult', '')
    
    # Get current conversation state
    call_data = conversation_data.get(call_sid, {})
    current_step = call_data.get('current_step', 'greeting')
    
    # Create TwiML response
    response = VoiceResponse()
    
    # Process response based on current step
    if current_step == 'greeting':
        # Save customer name
        call_data['name'] = speech_result
        call_data['current_step'] = 'phone_number'
        
        # Ask for phone number
        gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=3)
        gather.say(f"Hello {speech_result}, what is the best number to call you back on?")
        response.append(gather)
    
    elif current_step == 'phone_number':
        # Save phone number
        call_data['phone_number'] = speech_result
        call_data['current_step'] = 'service'
        
        # Ask about service needed
        gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
        gather.say("What service can we help you with?")
        response.append(gather)
    
    elif current_step == 'service':
        # Save service requested
        call_data['service_requested'] = speech_result
        
        # Check if service is for a car
        if any(word in speech_result.lower() for word in ['car', 'vehicle', 'auto', 'automobile']):
            call_data['current_step'] = 'vehicle_info'
            gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
            gather.say("What is the make, model and year of the vehicle?")
            response.append(gather)
        # Check if it's a business call
        elif any(word in speech_result.lower() for word in ['business', 'company', 'office', 'store', 'shop']):
            call_data['current_step'] = 'business_name'
            gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
            gather.say("What is the name of the business?")
            response.append(gather)
        else:
            # Go directly to location
            call_data['current_step'] = 'location'
            gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
            gather.say("What is the address where you need help?")
            response.append(gather)
    
    elif current_step == 'vehicle_info':
        # Save vehicle information
        call_data['vehicle_info'] = speech_result
        call_data['current_step'] = 'location'
        
        # Ask for location
        gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
        gather.say("What is the address where you need help?")
        response.append(gather)
    
    elif current_step == 'business_name':
        # Save business name
        call_data['business_name'] = speech_result
        call_data['current_step'] = 'location'
        
        # Ask for location
        gather = Gather(input='speech', action='/handle-response', method='POST', speech_timeout=5)
        gather.say("What is the address where you need help?")
        response.append(gather)
    
    elif current_step == 'location':
        # Save location
        call_data['service_location'] = speech_result
        call_data['current_step'] = 'completed'
        
        # Final message
        response.say("Ok, please stay by your phone, the technician will call you right back.")
        
        # Save the completed conversation data
        save_conversation_data(call_data)
    
    # Update conversation state
    conversation_data[call_sid] = call_data
    
    # If no input received, retry the current question
    if not speech_result:
        response.redirect('/handle-response')
    
    return str(response)

def save_conversation_data(data):
    """Save the conversation data to a file"""
    # Create a directory for call logs if it doesn't exist
    os.makedirs('call_logs', exist_ok=True)
    
    # Generate a filename based on timestamp
    import datetime
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"call_logs/call_{timestamp}.json"
    
    # Write the data to a JSON file
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
