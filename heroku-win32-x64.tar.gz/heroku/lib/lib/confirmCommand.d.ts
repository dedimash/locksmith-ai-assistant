export default function confirmCommand(app: string, confirm?: string, message?: string): Promise<void>;
