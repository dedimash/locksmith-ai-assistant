import { SniEndpoint } from '../types/sni_endpoint';
export default function (endpoints: SniEndpoint[]): void;
