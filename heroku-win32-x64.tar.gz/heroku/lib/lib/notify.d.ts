export default function (subtitle: string, message: string, success?: boolean): void;
