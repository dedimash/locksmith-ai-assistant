import { ParserOutput } from '@oclif/core/lib/interfaces/parser';
export declare const validateArgvPresent: (argv: ParserOutput['argv'], isUnset?: boolean) => void;
